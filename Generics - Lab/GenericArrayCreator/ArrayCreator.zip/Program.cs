﻿using System;

namespace GenericArrayCreator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int[] nums = ArrayCreator.Create(10, 33); 

        }
    }
}
