﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car()
            {
                Make = "BMW",
                Model = "x3",
                Year = 2006,
                FuelConsumption = 0.3,
                FuelQuantity = 100
            };

            while (true)
            {
                Console.WriteLine("where to go ?");
                car.Drive(int.Parse(Console.ReadLine()));
                Console.WriteLine(car.FuelQuantity);
                Console.WriteLine(car.WhoAmI());

            }
        }
    }
}
