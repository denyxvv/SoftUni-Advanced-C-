﻿using System;

namespace DateModifier
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateModifier.DateDifference(Console.ReadLine(), Console.ReadLine()));
        }
    }
}
